# Checklist for my First PR (PR Noobie)

Let’s make this concrete and repeatable.

# One‑time repo setup (GitHub)

1. **Branches**

* Default branch: `main`
* Long‑lived integration branch (optional): `develop`

2. **Branch protection**

* Protect `main` (and `develop` if you use it):

  * Require PRs before merge
  * Require **squash merge only**
  * Require up‑to‑date with base (reenable after enabling Actions)
  * Require status checks to pass: `lint`, `typecheck`, `test`
  * Dismiss stale reviews on new commits
  * Restrict who can push (admins only)

3. **Required checks (GitHub Actions)**
   Create three minimal workflows so checks exist and can be required:

```yaml
# .github/workflows/lint.yml
name: lint
on: [push, pull_request]
jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: '3.12' }
      - run: pipx install poetry
      - run: poetry install --no-root
      - run: poetry run pre-commit run --all-files
```

```yaml
# .github/workflows/typecheck.yml
name: typecheck
on: [push, pull_request]
jobs:
  mypy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: '3.12' }
      - run: pipx install poetry
      - run: poetry install --no-root
      - run: poetry run mypy .
```

```yaml
# .github/workflows/test.yml
name: test
on: [push, pull_request]
jobs:
  pytest:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: '3.12' }
      - run: pipx install poetry
      - run: poetry install --no-root
      - run: poetry run pytest -q
```

4. **PR template & CODEOWNERS**

```md
<!-- .github/pull_request_template.md -->
## Summary
<one-liner of the change>

## Context
Fixes #123 (link to issue). Why now?

## Changes
- bullet 1
- bullet 2

## Screenshots/CLI output (if relevant)

## Checklist
- [ ] Tests added/updated
- [ ] Docs updated (README/RELEASE.md)
- [ ] Lint/typecheck/test pass locally
- [ ] Backward compatibility considered
```

```txt
# .github/CODEOWNERS
* @genuinemerit
```

5. **Pre-commit is already set up** (you’re using Black/Isort/Mypy). Ensure local install:

```bash
pre-commit install
```

---

# Per‑PR workflow (slow & steady)

## 0) Start from an issue

* Open a GitHub Issue describing the change.
* Label: `bug`/`enhancement`; add acceptance criteria.

## 1) Create a topic branch

```bash
git fetch origin
git switch develop         # or main if you’re trunk-based
git pull
git switch -c feat/short-kebab-summary-123  # or fix/, chore/, docs/
```

**Naming:** `type/summary-<issue#>` using Conventional Commit types.

## 2) Make small, focused commits

* Keep diffs < \~400 lines when possible.
* Commit message format:

  * `feat(parser): add PEG fallback for hex grid (#123)`
  * Body: why + what changed + any tradeoffs.

## 3) Keep it green locally

Run your local quality gates before every push:

```bash
poetry install --no-root
poetry run pre-commit run --all-files    # lint/format
poetry run mypy .
poetry run pytest -q
```

If you’ve got Make targets, fine:

```bash
make lint && make typecheck && make test
```

## 4) Rebase to stay current

Before pushing/opening the PR:

```bash
git fetch origin
git rebase origin/develop   # or origin/main
# resolve conflicts if any, then:
git push -u origin feat/short-kebab-summary-123
```

(Rebase > merge for clean history; you’ll squash at PR merge anyway.)

---

# Open the PR

* Base: `develop` (or `main` if trunk‑based)
* Compare: your `feat/...` branch
* Fill the **PR template**:

  * Link the issue: “Fixes #123”
  * Summarize scope and risk
  * Note testing evidence (commands, screenshots)

**Size & scope sanity check**

* Only one logical change
* Includes tests
* Includes docs/`RELEASE.md` notes if user‑visible

(Optional, with `gh` CLI):

```bash
gh pr create --fill --base develop --head feat/short-kebab-summary-123 --draft
```

---

# Review loop

1. **CI must be green** (lint/typecheck/test). Fix failures locally, `--amend` or new commits, and `git push`.
2. **Self‑review**: use “Files changed” diff, comment on risky parts, point reviewers to critical decisions.
3. **Respond to review**:

   * Apply suggestions
   * Re‑run local checks
   * `git commit --fixup <sha>` for review changes is fine; they’ll be squashed later.
4. **Keep updated**:

   ```bash
   git fetch origin
   git rebase origin/develop
   git push --force-with-lease
   ```

---

# Merge & post‑merge

* Ensure:

  * All required checks pass
  * At least one approval (or CODEOWNERS approval)
  * PR is set to **Squash and merge**
* When squashing, **edit the squash commit message**:

  * Start with a Conventional Commit header summarizing the PR
  * Include “Fixes #123”
* Delete the topic branch (GitHub UI will offer this).
* If merging to `develop`, follow your release cadence:

  * Cut a release branch from `develop` when ready
  * Bump version (SemVer)
  * Update `RELEASE.md` and changelog
  * PR release branch → `main` (squash or merge commit per your policy)
  * Tag `vX.Y.Z`, create GitHub Release notes

---

## Definition of Done (copy into your PR)

* [ ] Branch up‑to‑date and rebased (no merge commits)
* [ ] Lint/typecheck/tests pass locally
* [ ] CI green on PR
* [ ] Tests add/updated and meaningful
* [ ] Docs updated (README/RELEASE.md/CLI help)
* [ ] Small, single‑purpose PR with clear risk notes
* [ ] Issue linked (`Fixes #…`)
* [ ] Squash merge ready with clean message

---

## Minimal first PR candidate (suggestion)

If you want a “Day 1” clean PR that exercises the whole pipeline without touching runtime logic:

1. Add `.github/` workflows above
2. Add `.github/pull_request_template.md` and `.github/CODEOWNERS`
3. Add/confirm `RELEASE.md` skeleton (purpose, release cadence, versioning, cut process)
4. Ensure `pre-commit` and `pyproject.toml` are consistent with CI

Open PR: `chore: bootstrap CI, PR template, CODEOWNERS (#1)`

---

If you want, I can scan your repo layout and propose the exact first PR diff (filenames, content) next.

